import http from "../http-common";
import axios from "axios";

class EmployeeDataService {
  getAll() {
const getReq = axios.create({
  baseURL: process.env.REACT_APP_GET_EMPLOYEES,
  headers: {
    "Content-type": "application/json"
  }
});
    return getReq.get();
  
  }

  get(id) {
    return http.get(`/employees/${id}`);
  }

  create(data) {
    const postReq = axios.create({
      baseURL: process.env.REACT_APP_CREATE_EMPLOYEE,
     
      headers: {
        "Content-type": "application/json",
      }
    });
        return postReq.post('' , data);
    // return http.post("/employees", data);
  }

  update(id, data) {
    // return http.put(`/employees/${id}`, data);
    const putReq = axios.create({
      baseURL: process.env.REACT_APP_UPDATE_EMPLOYEE,
     
      headers: {
        "Content-type": "application/json",
      }
    });
        return putReq.put('/' , data);
  }

  delete(id) {
      // return http.put(`/employees/${id}`, data);
      const deleteReq = axios.create({
        baseURL: process.env.REACT_APP_DELETE_EMPLOYEE,
       
        headers: {
          "Content-type": "application/json",
        }
      });
          return deleteReq.delete(`/Employe/DeleteEmployee?id=${id}`);
    // return http.delete(`/employees/${id}`);
  }

  deleteAll() {
    return http.delete(`/employees`);
  }

  findByTitle(name) {
    return http.get(`/employees?name=${name}`);
  }
}

export default new EmployeeDataService();