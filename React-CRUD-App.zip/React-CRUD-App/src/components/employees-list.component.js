import React, { Component } from "react";
import EmployeDataService from "../services/employee.service";
import { Link } from "react-router-dom";

export default class EmployeesList extends Component {
  constructor(props) {
    super(props);
    this.onChangeSearchName = this.onChangeSearchName.bind(this);
    this.retrieveEmployees = this.retrieveEmployees.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActiveEmployee = this.setActiveEmployee.bind(this);
    this.removeAllEmployees = this.removeAllEmployees.bind(this);
    this.searchEmployee = this.searchEmployee.bind(this);

    this.state = {
      employees: [],
      currentEmployee: null,
      currentIndex: -1,
      searchEmployee: ""
    };
  }

  componentDidMount() {
    this.retrieveEmployees();
  }

  onChangeSearchName(e) {
    const searchEmployee = e.target.value;

    this.setState({
      searchEmployee: searchEmployee
    });
  }

  retrieveEmployees() {
    EmployeDataService.getAll()
      .then(response => {
        this.setState({
          employees: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveEmployees();
    this.setState({
      currentEmployee: null,
      currentIndex: -1
    });
  }

  setActiveEmployee(employee, index) {
    this.setState({
      currentEmployee: employee,
      currentIndex: index
    });
  }

  removeAllEmployees() {
    EmployeDataService.deleteAll()
      .then(response => {
        console.log(response.data);
        this.refreshList();
      })
      .catch(e => {
        console.log(e);
      });
  }

  searchEmployee() {
    this.setState({
      currentEmployee: null,
      currentIndex: -1
    });

    EmployeDataService.findByName(this.state.searchEmployee)
      .then(response => {
        this.setState({
          employees: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { searchEmployee, employees, currentEmployee, currentIndex } = this.state;

    return (
      <div className="list row">
        {/* <div className="col-md-8">
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Search by name"
              value={searchEmployee}
              onChange={this.onChangeSearchName}
            />
            <div className="input-group-append">
              <button
                className="btn btn-outline-secondary"
                type="button"
                onClick={this.searchEmployee}
              >
                Search
              </button>
            </div>
          </div>
        </div> */}
        <div className="col-md-6">
          <h4>Employees List</h4>

          <ul className="list-group">
            {employees &&
              employees.map((employee, index) => (
                <li
                  className={
                    "list-group-item " +
                    (index === currentIndex ? "active" : "")
                  }
                  onClick={() => this.setActiveEmployee(employee, index)}
                  key={index}
                >
                  {employee.name}
                </li>
              ))}
          </ul>
{/* 
          <button
            className="m-3 btn btn-sm btn-danger"
            onClick={this.removeAllEmployees}
          >
            Remove All
          </button> */}
        </div>
        <div className="col-md-6">
          {currentEmployee ? (
            <div>
              <h4>Employee</h4>
              <div>
                <label>
                  <strong>Name:</strong>
                </label>{" "}
                {currentEmployee.name}
              </div>
              {/* <div>
                <label>
                  <strong>Department:</strong>
                </label>{" "}
                {currentEmployee.department}
              </div> */}
              {/* <div>
                <label>
                  <strong>Status:</strong>
                </label>{" "}
                {currentEmployee.published ? "Published" : "Pending"}
              </div> */}

              <Link
                to={"/employees/" + currentEmployee.id +"/" + currentEmployee.name}
                className="badge badge-warning"
              >
                Edit
              </Link>
            
            </div>
          ) : (
            <div>
              <br />
              <p>Please click on a Employee Name...</p>
            </div>
          )}
        </div>
      </div>
    );
  }
}
