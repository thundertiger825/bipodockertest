﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
	public interface IEmployeInterface
	{
		Task<IEnumerable<Employe>> GetEmployees();
		Task<Employe> GetEmployee(int employeeId);
		Task<Employe> AddEmployee(Employe employee);
		Task<Employe> UpdateEmployee(Employe employee);
		void DeleteEmployee(int employeeId);
	}
}
