﻿using DataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
	public class EmployeRepository : IEmployeeRepository
	{
		private readonly ApplicationDbContext  _dbContext;

		public EmployeRepository(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		
		public async Task<IEnumerable<Employe>> GetEmployees()
		{
			return await _dbContext.Employees.ToListAsync();
		}

		public async Task<Employe> GetEmployee(int employeeId)
		{
			return await _dbContext.Employees
				.FirstOrDefaultAsync(e => e.Id == employeeId);
		}

        public async Task<Employe> AddEmployee(Employe employee)
        {
            var result = await _dbContext.Employees.AddAsync(employee);
            await _dbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Employe> UpdateEmployee(Employe employee)
        {
            var result = await _dbContext.Employees
                .FirstOrDefaultAsync(e => e.Id == employee.Id);

            if (result != null)
            {
                result.Name = employee.Name;
              

                await _dbContext.SaveChangesAsync();

                return result;
            }

            return null;
        }

        public async void DeleteEmployee(int employeeId)
        {
            var result = await _dbContext.Employees
                .FirstOrDefaultAsync(e => e.Id == employeeId);
            if (result != null)
            {
                _dbContext.Employees.Remove(result);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
