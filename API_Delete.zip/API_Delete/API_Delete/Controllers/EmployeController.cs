﻿using DataLayer;
using DataLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_Delete.Controllers
{
    [Route("api/Employe")]
    [ApiController]
    public class EmployeController : Controller
	{
        //private readonly IEmployeeRepository _employeInterface = null;
        private readonly ApplicationDbContext _applicationDbContext;


        public EmployeController(IEmployeeRepository employeInterface,ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
            //_employeInterface = employeInterface;

        }

       
        [HttpDelete]
        [Route("DeleteEmployee")]
        public async Task<ActionResult<Employe>> DeleteEmployee(int id)
        {
            try
            {
                var result = await _applicationDbContext.Employees
                .FirstOrDefaultAsync(e => e.Id == id);
                if (result != null)
                {
                    var a = _applicationDbContext.Employees.Remove(result);
                    await _applicationDbContext.SaveChangesAsync();
                }
                return null;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}
