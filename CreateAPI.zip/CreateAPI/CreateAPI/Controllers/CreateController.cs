﻿using CreateAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CreateAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class CreateController : Controller
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public CreateController(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }
        [HttpGet]
           public IEnumerable<Employee> GetEmployee()
        {
            var employee = _applicationDbContext.Employees.ToList();
            return employee;
        }
    }
}
