﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataLayer
{
	public class EmployeInterface : IEmployeInterface
	{

		private IEmployeeRepository _EmployeeRepository = null;

		public EmployeInterface(IEmployeeRepository e)
		{
			_EmployeeRepository = e;
		}


		public Task<Employe> AddEmployee(Employe employee)
		{
			throw new NotImplementedException();
		}

		public void DeleteEmployee(int employeeId)
		{
		 _EmployeeRepository.DeleteEmployee(employeeId);
		}

		public Task<Employe> GetEmployee(int employeeId)
		{
			return _EmployeeRepository.GetEmployee(employeeId);
		}
		 
		public Task<IEnumerable<Employe>> GetEmployees()
		{
			throw new NotImplementedException();
		}

		public Task<Employe> UpdateEmployee(Employe employee)
		{
			throw new NotImplementedException();
		}
	}
}
